gcc -Wall -g Lab6.1.2.c -lm -o Lab6.1.2
rm -f output.txt
./Lab6.1.2 > output.txt
